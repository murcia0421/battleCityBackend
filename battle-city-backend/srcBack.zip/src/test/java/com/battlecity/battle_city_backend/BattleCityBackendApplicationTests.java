package com.battlecity.battle_city_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BattleCityBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
