package com.battlecity.battle_city_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BattleCityBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(BattleCityBackendApplication.class, args);
	}

}
